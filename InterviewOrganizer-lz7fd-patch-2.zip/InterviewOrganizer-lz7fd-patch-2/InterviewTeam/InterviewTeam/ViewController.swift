//
//  ViewController.swift
//  InterviewTeam
//
//  Created by Chule Hou on 4/24/19.
//  Copyright © 2019 Chule Hou. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

