//
//  HomePageViewController.swift
//  Notes
//
//  Created by Chule Hou on 5/7/19.
//  Copyright © 2019 Tech Innovator. All rights reserved.
//

import UIKit

class HomePageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    


}
